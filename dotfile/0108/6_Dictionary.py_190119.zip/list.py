list=['오늘','저녁은','치킨이','닭']   #문자열 저장
list[0]='내일'  #수정
print(list)     #출력
em=[]           #빈리스트 생성하는 방법
for x in list:
    print (x)

list.append('치킨')
tup=('a','b','c')       #튜플은 소괄호
print(type(tup))               #튜플의 타입출력
day='2016-05-12'
type(day)               #타입 출력
print(type(m))                 #리스트'm'의 타입 출력
day.split('-')          #'-'기준으로 나눔


