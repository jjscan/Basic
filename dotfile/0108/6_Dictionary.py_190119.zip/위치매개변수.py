def my_avg(x1, x2):

avg_val = (x1 + x2)/ 2

return avg_val

my_avg(2, 4)

my_avg(2)


