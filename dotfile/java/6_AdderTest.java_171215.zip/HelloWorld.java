
public class HelloWorld {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Hello World1");
		System.out.println("Hello World2");
		System.out.println("Hello World3");
		System.out.println("Hello World4");

		System.out.println("1+1");
		System.out.println(1 + 1);
		// 1+1=2
		System.out.println("1+1=" + 2);
		System.out.println("1+1=" + (1 + 1));
		// 2*8=16
		/*
		 * System.out.println("2*8="+2*8); System.out.println("2*8="+(2*8));
		 */

	}

}
