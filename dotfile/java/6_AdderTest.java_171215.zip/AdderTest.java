				



				public class AdderTest {
				
					public static void main(String[] args) {
						// TODO Auto-generated method stub
						int num1=10, num2=20;
						int result = ++num1 + num2;
						num1++;
						++num1;
						System.out.println(result);
					}
				
				}
