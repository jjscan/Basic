

				public class VariableTest {
					
					public static void main(String[] args) {
						int num1 = 20;
						double pi1 = 3.14;
						float pi2 = 3.14f;
						char ch = 'A';
						boolean status = false;
						status = true;
						
						System.out.println("num1 : "+num1);
						System.out.println("pi1: "+pi1);
						System.out.println("pi2 : "+pi2);
						System.out.println("ch : "+ch);
						System.out.println("status : "+status);
						}
				}
