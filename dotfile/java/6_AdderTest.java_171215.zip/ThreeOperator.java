



	public class ThreeOperator {
	
		public static void main(String[] args) {
			// TODO Auto-generated method stub
			int num = 20;
			
			String msg = num % 2 == 0 ? "이 숫자는 짝수 입니다." : "이 숫자는 홀수 입니다.";
			
			System.out.println(msg);
		}
	
	}
